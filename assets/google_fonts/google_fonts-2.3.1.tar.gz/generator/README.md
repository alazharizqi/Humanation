To generate the `GoogleFonts` class:

1. Navigate to the root directory of this project.
2. run: `$ dart generator/generator.dart`
